using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using System.Data.SqlClient;

public partial class Select_Profile : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    SqlDataReader rs;
    protected void Page_Load(object sender, EventArgs e)
    {
        cn.ConnectionString = "Data Source=PRASHANT-PC\\SQLEXPRESS;Initial Catalog=Matrimonial1;Integrated Security=True";
        SqlDataSource1.SelectCommand = "select * from User_Profile where Reg_No='" + Session["RNO"].ToString() + "'";
        SqlDataSource2.SelectCommand = "select * from Register where Reg_No='" + Session["RNO"].ToString() + "'";
        SqlDataSource3.SelectCommand = "select * from Picture_Profile where Reg_No='" + Session["RNO"].ToString() + "'";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Send_Messages.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string email="";
        cn.Open();
        cmd.Connection =cn;
        cmd.CommandText="Select Reg_Email from Register where Reg_no='"+Session["RNO"].ToString()+"'";
        rs=cmd.ExecuteReader();
        while(rs.Read())
        {
            email=rs.GetValue(0).ToString();
        }
        rs.Close();
        cmd.Dispose();
        cn.Close();
        
        var fromAddress = new MailAddress("matrimonyswayamvar@gmail.com", "SWAYAMVARA");
        var toAddress = new MailAddress(email);
        string fromPassword = "nealgole007";
        string subject = "Profile Match";
        string body = "Hi,\nThere is a profile match on Swayamwara.com.\nVisit and Check for More Details";
        var smtp = new SmtpClient
        {
            Host = "smtp.gmail.com",
            Port = 587,
            EnableSsl = true,
            DeliveryMethod = SmtpDeliveryMethod.Network,
            UseDefaultCredentials = false,

            Credentials = new System.Net.NetworkCredential(fromAddress.Address, fromPassword)
        };
        using (var message = new MailMessage(fromAddress, toAddress)
        {
            Subject = subject,
            Body = body,

        })
        {
            smtp.Send(message);
            //textBox1.Text = "";
            //textBox2.Text = "";
            //textBox3.Text = "";
            //textBox4.Text = "";
            //openFileDialog1.FileName = "";
            //flag = 0;
            //MessageBox.Show("Mail Sent", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
