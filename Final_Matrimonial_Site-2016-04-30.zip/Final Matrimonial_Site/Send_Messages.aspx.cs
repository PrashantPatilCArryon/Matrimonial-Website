using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Send_Messages : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    SqlDataReader rs;
    string fid;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = Session["User"].ToString();

        if (s == "")
        {
            Response.Redirect("Default.aspx");
        }
        cn.ConnectionString = "Data Source=PRASHANT-PC\\SQLEXPRESS;Initial Catalog=Matrimonial1;Integrated Security=True";
        
        TextBox2.Text = Session["RNO"].ToString();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Auto_ID();
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "insert into SMessage values('" + fid + "','" + Session["User"].ToString() + "','" + TextBox2.Text + "','" + TextBox3.Text + "')";
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        cn.Close();
        TextBox3.Text = "";
        Label1.Text = "Message Sent";
    }

    public void Auto_ID()
    {
        int cnt;
        string id;
        int temp;
        temp = 0;
        cnt = 0;
        id = "";
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "select count(*) from SMessage";
        rs = cmd.ExecuteReader();
        while (rs.Read())
        {
            cnt = int.Parse(rs.GetValue(0).ToString());
        }
        rs.Close();
        cmd.Dispose();
        cn.Close();
        if (cnt > 0)
        {
            cn.Open();
            cmd.Connection = cn;
            cmd.CommandText = "select max(Mess_ID) from SMessage";
            rs = cmd.ExecuteReader();
            while (rs.Read())
            {
                id = rs.GetValue(0).ToString();
            }
            rs.Close();
            cmd.Dispose();
            cn.Close();
            temp = int.Parse(id.Substring(1, 4));
            temp++;
            id = "";
            id = temp.ToString();
            if (id.Length == 1)
            {
                id = "M000" + id;
            }
            else if (id.Length == 2)
            {
                id = "M00" + id;
            }
            else if (id.Length == 3)
            {
                id = "M0" + id;
            }
            else if (id.Length == 4)
            {
                id = "M" + id;
            }
            fid = id;
        }
        else
        {
            fid = "M0001";
        }
    }

}
