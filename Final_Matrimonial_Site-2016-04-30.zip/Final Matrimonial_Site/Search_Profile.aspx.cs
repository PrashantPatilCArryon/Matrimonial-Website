using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Search_Profile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex == 0)
        {
            Session["G"] = "Female";
        }
        else
        {
            Session["G"] = "Male";
        }
        Session["Q"] = TextBox1.Text;
        Session["R"] = TextBox2.Text;
        Session["M"] = TextBox3.Text;
        Session["AF"] = DropDownList2.SelectedItem.Text;
        Session["AT"] = DropDownList3.SelectedItem.Text;
        Session["C"] = DropDownList4.SelectedItem.Text;
        Response.Redirect("Search_Result.aspx");
    }
}
