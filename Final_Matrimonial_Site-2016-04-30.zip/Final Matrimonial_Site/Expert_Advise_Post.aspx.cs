﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Expert_Advise_Post : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    SqlDataReader rs;
    string fid;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = Session["User"].ToString();

        if (s == "")
        {
            Response.Redirect("Default.aspx");
        }
        cn.ConnectionString = "Data Source=PRASHANT-PC\\SQLEXPRESS;Initial Catalog=Matrimonial1;Integrated Security=True";

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Auto_ID();
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "insert into Expert_Advise values('" + fid + "','" + Session["User"].ToString() + "','" + System.DateTime.Now.ToShortDateString() + "','" + TextBox1.Text + "','Pending')";
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        cn.Close();
        TextBox1.Text = "";
        Label1.Text = "Query Posted. Your Unique ID is : " + fid;
    }

    public void Auto_ID()
    {
        int cnt;
        string id;
        int temp;
        temp = 0;
        cnt = 0;
        id = "";
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "select count(*) from Expert_Advise";
        rs = cmd.ExecuteReader();
        while (rs.Read())
        {
            cnt = int.Parse(rs.GetValue(0).ToString());
        }
        rs.Close();
        cmd.Dispose();
        cn.Close();
        if (cnt > 0)
        {
            cn.Open();
            cmd.Connection = cn;
            cmd.CommandText = "select max(QID) from Expert_Advise";
            rs = cmd.ExecuteReader();
            while (rs.Read())
            {
                id = rs.GetValue(0).ToString();
            }
            rs.Close();
            cmd.Dispose();
            cn.Close();
            temp = int.Parse(id.Substring(1, 4));
            temp++;
            id = "";
            id = temp.ToString();
            if (id.Length == 1)
            {
                id = "Q000" + id;
            }
            else if (id.Length == 2)
            {
                id = "Q00" + id;
            }
            else if (id.Length == 3)
            {
                id = "Q0" + id;
            }
            else if (id.Length == 4)
            {
                id = "Q" + id;
            }
            fid = id;
        }
        else
        {
            fid = "Q0001";
        }
    }
}
