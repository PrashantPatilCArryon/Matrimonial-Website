using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class U_Profile : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    SqlDataReader rs;
    string s = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        s = Session["User"].ToString();

        if (s == "")
        {
            Response.Redirect("Default.aspx");
        }
        cn.ConnectionString = "Data Source=PRASHANT-PC\\SQLEXPRESS;Initial Catalog=Matrimonial1;Integrated Security=True";
        TextBox1.Text = s;
        if (!IsPostBack)
        {
            string diet = "", smoke = "", drink = "", pv = "", compl = "", bodytype = "";
            int rcnt = 0;
            cn.Open();
            cmd.Connection = cn;
            cmd.CommandText = "select * from User_Profile where Reg_No='" + s + "'";
            rs = cmd.ExecuteReader();
            while (rs.Read())
            {
                //TextBox1.Text = rs.GetValue(0).ToString();
                DropDownList1.Text = rs.GetValue(1).ToString();
                TextBox3.Text = rs.GetValue(2).ToString();
                TextBox5.Text = rs.GetValue(3).ToString();
                TextBox6.Text = rs.GetValue(4).ToString();
                TextBox7.Text = rs.GetValue(5).ToString();
                TextBox8.Text = rs.GetValue(6).ToString();
                TextBox9.Text = rs.GetValue(7).ToString();
                diet = rs.GetValue(9).ToString();
                smoke = rs.GetValue(10).ToString();
                drink = rs.GetValue(11).ToString(); 
                pv = rs.GetValue(12).ToString();
                compl = rs.GetValue(13).ToString();
                bodytype = rs.GetValue(14).ToString();
                rcnt++;
            }
            rs.Dispose();
            cmd.Dispose();
            cn.Close();
            if (diet == "Non-Veg")
            {
                RadioButton2.Checked = true;
            }
            else if (diet == "Eggetarian")
            {
                RadioButton3.Checked = true;
            }
            else if (diet == "Jain")
            {
                RadioButton4.Checked = true;
            }
            else if (diet == "Vegan")
            {
                RadioButton5.Checked = true;
            }
            else
            {
                RadioButton1.Checked = true;
            }

            if (smoke == "No")
            {
                RadioButton6.Checked = true;
            }
            else if (smoke == "Occasionally")
            {
                RadioButton7.Checked = true;
            }
            else
            {
                RadioButton8.Checked = true;
            }

            if (drink == "No")
            {
                RadioButton9.Checked = true;
            }
            else if (drink == "Occasionally")
            {
                RadioButton10.Checked = true;
            }
            else
            {
                RadioButton11.Checked = true;
            }

            if (pv == "Traditional")
            {
                RadioButton12.Checked = true;
            }
            else if (pv == "Moderate")
            {
                RadioButton13.Checked = true;
            }
            else
            {
                RadioButton14.Checked = true;
            }

            if (compl == "Very Fair")
            {
                RadioButton15.Checked = true;
            }
            else if (compl == "Fair")
            {
                RadioButton16.Checked = true;
            }
            else if (compl == "Whitsh")
            {
                RadioButton17.Checked = true;
            }
            else
            {
                RadioButton18.Checked = true;
            }

            if (bodytype == "Slim")
            {
                RadioButton19.Checked = true;
            }
            else if (bodytype == "Athletic")
            {
                RadioButton20.Checked = true;
            }
            else if (bodytype == "Average")
            {
                RadioButton21.Checked = true;
            }
            else
            {
                RadioButton22.Checked = true;
            }

            cn.Open();
            cmd.Connection = cn;
            cmd.CommandText = "select Reg_Name from Register where Reg_No='" + s + "'";
            rs = cmd.ExecuteReader();
            while (rs.Read())
            {
                TextBox2.Text = rs.GetValue(0).ToString();
            }
            rs.Dispose();
            cmd.Dispose();
            cn.Close();
            if (rcnt > 0)
            {
                DateTime d = new DateTime();
                d = DateTime.Parse(TextBox3.Text);
                DateTime d1 = new DateTime();
                d1 = System.DateTime.Now;
                TimeSpan t = d1.Subtract(d);
                int nod = t.Days;
                int noy = (int)nod / 365;
                int rd = (nod - (noy * 365));
                TextBox4.Text = noy.ToString() + " years, " + rd.ToString() + " days.";
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DateTime d = new DateTime();
        d = DateTime.Parse(TextBox3.Text);
        DateTime d1 = new DateTime();
        d1 = System.DateTime.Now;
        TimeSpan t = d1.Subtract(d);
        int nod = t.Days;
        int noy = (int)nod / 365;
        int rd = (nod - (noy * 365));
        TextBox4.Text = noy.ToString() + " years, " + rd.ToString() + " days.";

        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "delete from User_Profile where Reg_No='" + s + "'";
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        cn.Close();

        string diet, smoke, drink, pv, comp, bt;

        diet = "NA";
        smoke = "NA";
        drink = "NA";
        pv = "NA";
        comp = "NA";
        bt = "NA";

        if (RadioButton1.Checked == true)
        {
            diet = RadioButton1.Text;
        }
        else if (RadioButton2.Checked == true)
        {
            diet = RadioButton2.Text;
        }
        else if (RadioButton3.Checked == true)
        {
            diet = RadioButton3.Text;
        }
        else if (RadioButton4.Checked == true)
        {
            diet = RadioButton4.Text;
        }
        else if (RadioButton5.Checked == true)
        {
            diet = RadioButton5.Text;
        }

        if (RadioButton6.Checked == true)
        {
            smoke = RadioButton6.Text;
        }
        else if (RadioButton7.Checked == true)
        {
            smoke = RadioButton7.Text;
        }
        else if (RadioButton8.Checked == true)
        {
            smoke = RadioButton8.Text;
        }

        if (RadioButton9.Checked == true)
        {
            drink = RadioButton9.Text;
        }
        else if (RadioButton10.Checked == true)
        {
            drink = RadioButton10.Text;
        }
        else if (RadioButton11.Checked == true)
        {
            drink = RadioButton11.Text;
        }

        if (RadioButton12.Checked == true)
        {
            pv = RadioButton12.Text;
        }
        else if (RadioButton13.Checked == true)
        {
            pv = RadioButton13.Text;
        }
        else if (RadioButton14.Checked == true)
        {
            pv = RadioButton14.Text;
        }

        if (RadioButton15.Checked == true)
        {
            comp = RadioButton15.Text;
        }
        else if (RadioButton16.Checked == true)
        {
            comp = RadioButton16.Text;
        }
        else if (RadioButton17.Checked == true)
        {
            comp = RadioButton17.Text;
        }
        else if (RadioButton18.Checked == true)
        {
            comp = RadioButton18.Text;
        }

        if (RadioButton19.Checked == true)
        {
            bt = RadioButton19.Text;
        }
        else if (RadioButton20.Checked == true)
        {
            bt = RadioButton20.Text;
        }
        else if (RadioButton21.Checked == true)
        {
            bt = RadioButton21.Text;
        }
        else if (RadioButton22.Checked == true)
        {
            bt = RadioButton22.Text;
        }
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "insert into User_Profile values('" + TextBox1.Text + "','" + DropDownList1.SelectedItem + "','" + TextBox3.Text + "'," + noy.ToString() + ",'" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + DropDownList2.SelectedItem.Text + "','" + diet + "','" + smoke + "','" + drink + "','" + pv + "','" + comp + "','" + bt + "','" + DropDownList3.SelectedItem.Text + "','" + DropDownList4.Text + "','" + TextBox9.Text + "')";
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        cn.Close();

        Label1.Text = "Profile Saved";
    }
    
}
