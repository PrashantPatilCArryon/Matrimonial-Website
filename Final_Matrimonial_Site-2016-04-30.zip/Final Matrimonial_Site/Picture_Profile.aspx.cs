using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Picture_Profile : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    //SqlDataReader rs;
    string s;
    protected void Page_Load(object sender, EventArgs e)
    {
        s = Session["User"].ToString();

        if (s == "")
        {
            Response.Redirect("Default.aspx");
        }
        cn.ConnectionString = "Data Source=PRASHANT-PC\\SQLEXPRESS;Initial Catalog=Matrimonial1;Integrated Security=True";
        SqlDataSource1.SelectCommand = "select * from Picture_Profile where Reg_No='" + Session["User"].ToString() + "'";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (FileUpload1.FileName != "")
            {
                
                string pth = "~\\Picture_Profile\\" + s + "\\" + FileUpload1.FileName;
                FileUpload1.SaveAs(MapPath(pth));
                
                pth = pth.Replace("\\","\\\\");
                cn.Open();
                cmd.Connection = cn;
                cmd.CommandText = "delete from Picture_Profile where Reg_No='"+s+"'";
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                cn.Close();

                cn.Open();
                cmd.Connection = cn;
                cmd.CommandText = "insert into Picture_Profile values('" + s + "','" + pth + "')";
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                cn.Close();
                Label1.Text = "Picture Uploaded";
                SqlDataSource1.SelectCommand = "Select * from Picture_Profile";
                SqlDataSource1.SelectCommand = "select * from Picture_Profile where Reg_No='" + Session["User"].ToString() + "'";
            }
        }
        catch
        {
            Label1.Text = "Cannot Upload Picture";
        }
    }
}
