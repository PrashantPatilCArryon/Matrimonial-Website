using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Register : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    SqlDataReader rs;
    protected void Page_Load(object sender, EventArgs e)
    {
        cn.ConnectionString = "Data Source=PRASHANT-PC\\SQLEXPRESS;Initial Catalog=Matrimonial1;Integrated Security=True";
        int cnt;
        string id;
        int temp;
        temp = 0;
        cnt = 0;
        id = "";
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "select count(*) from Register";
        rs = cmd.ExecuteReader();
        while (rs.Read())
        {
            cnt = int.Parse(rs.GetValue(0).ToString());
        }
        rs.Close();
        cmd.Dispose();
        cn.Close();
        if (cnt > 0)
        {
            cn.Open();
            cmd.Connection = cn;
            cmd.CommandText = "select max(Reg_No) from Register";
            rs = cmd.ExecuteReader();
            while (rs.Read())
            {
                id = rs.GetValue(0).ToString();
            }
            rs.Close();
            cmd.Dispose();
            cn.Close();
            temp = int.Parse(id.Substring(1, 4));
            temp++;
            id = "";
            id = temp.ToString();
            if (id.Length == 1)
            {
                id = "R000" + id;
            }
            else if (id.Length == 2)
            {
                id = "R00" + id;
            }
            else if (id.Length == 3)
            {
                id = "R0" + id;
            }
            else if (id.Length == 4)
            {
                id = "R" + id;
            }
            Label1.Text = id;
        }
        else
        {
            Label1.Text = "R0001";
        }
        TextBox1.Focus();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int ucnt = 0;
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "select count(*) from Register where Reg_User='" + TextBox8.Text + "'";
        rs = cmd.ExecuteReader();
        while (rs.Read())
        {
            ucnt = int.Parse(rs.GetValue(0).ToString());
        }
        rs.Close();
        cmd.Dispose();
        cn.Close();
        if (ucnt > 0)
        {
            Label2.Text = "Username already in Use !!!";
            TextBox8.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
        }
        else
        {
            int ecnt = 0;
            cn.Open();
            cmd.Connection = cn;
            cmd.CommandText = "select count(*) from Register where Reg_Email='" + TextBox3.Text + "'";
            rs = cmd.ExecuteReader();
            while (rs.Read())
            {
                ecnt = int.Parse(rs.GetValue(0).ToString());
            }
            rs.Close();
            cmd.Dispose();
            cn.Close();
            if (ecnt > 0)
            {
                Label2.Text = "Email Id already Registered !!!";
                TextBox3.Text = "";
            }
            else
            {
                cn.Open();
                cmd.Connection = cn;
                cmd.CommandText = "insert into Register values('" + Label1.Text + "','" + TextBox1.Text + "','" + TextBox7.Text + "','" + DropDownList1.SelectedItem.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox8.Text + "','" + TextBox6.Text + "')";
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                cn.Close();

                cn.Open();
                cmd.Connection = cn;
                cmd.CommandText = "insert into Login values('" + TextBox8.Text + "','" + TextBox5.Text + "')";
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                cn.Close();

                System.IO.Directory.CreateDirectory(MapPath("~\\Picture_Profile\\" + Label1.Text));

                Label1.Text = "";
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";
                TextBox5.Text = "";
                TextBox6.Text = "";
                TextBox7.Text = "";
                TextBox8.Text = "";
                Label2.Text = "User Registered Successfully";
            }
        }
    }




    
}
