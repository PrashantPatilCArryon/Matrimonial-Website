using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class View_Message : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();

    protected void Page_Load(object sender, EventArgs e)
    {
        string s = Session["User"].ToString();

        if (s == "")
        {
            Response.Redirect("Default.aspx");
        }
        cn.ConnectionString = "Data Source=PRASHANT-PC\\SQLEXPRESS;Initial Catalog=Matrimonial1;Integrated Security=True";
        SqlDataSource1.SelectCommand = "select * from SMessage where Receiver_No='" + Session["User"].ToString() + "'";
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox1.Text = GridView1.SelectedRow.Cells[0].Text;
        TextBox2.Text = GridView1.SelectedRow.Cells[1].Text;
        TextBox3.Text = GridView1.SelectedRow.Cells[2].Text;
        TextBox4.Text = GridView1.SelectedRow.Cells[3].Text;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "delete from SMessage where Mess_ID='" + TextBox1.Text + "'";
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        cn.Close();
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        SqlDataSource1.SelectCommand = "select * from SMessage where Receiver_No='" + Session["User"].ToString() + "'";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["RNO"] = TextBox2.Text;
        Response.Redirect("Send_Messages.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session["RNO"] = TextBox2.Text;
        Response.Redirect("Select_Profile.aspx");
    }
}
