create database	Matrimonial1

use Matrimonial1

create table Login
(Username varchar(20),
Password varchar(20))

create table Register
(Reg_No varchar(5) ,
Reg_Name varchar(20),
Reg_Address varchar(100),
Reg_Country varchar(20),
Reg_Contact varchar(10),
Reg_Email varchar(50),
Reg_User varchar(20),
Password_Hint varchar(20))

select * from Register

create table User_Profile
(Reg_No varchar(5),
Reg_Gender varchar(6),
Reg_DOB varchar(10),
Reg_Age numeric(3),
Reg_Qualification varchar(20),
Reg_Religion varchar(20),
Reg_MotherT varchar(20),
Reg_Hobbies varchar(50),
Reg_MT varchar(20),
Reg_Diet varchar(20),
Reg_Smoke varchar(20),
Reg_Drink varchar(20),
Reg_PV varchar(20),
Reg_Complex varchar(20),
Reg_Body varchar(20),
Reg_Working varchar(20),
Reg_AI varchar(20),
Reg_Info varchar(100))

create table Picture_Profile
(Reg_No varchar(5),
Pic_Path varchar(100))

create table SMessage
(Mess_ID varchar(5),
Sender_No varchar(5),
Receiver_No varchar(5),
Mess_Data varchar(200))

create table Admin_Login
(Username varchar(20),
Password varchar(20))

insert into Admin_Login values('Admin','Admin')

create table Expert_Advise
(QID varchar(5),
Reg_No varchar(5),
Post_Date varchar(20),
Question varchar(200),
Reply varchar(200))

select * from Register
Select * from Login
select * from User_Profile
select * from Picture_Profile
select * from Expert_Advise

select * from User_Profile where Reg_Gender='Female' and Reg_Qualification like '%B%' and Reg_Religion like '%Hindu%' and Reg_MotherT like '%Marathi%'