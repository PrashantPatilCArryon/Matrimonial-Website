using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Search_Result : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    SqlDataReader rs;
    protected void Page_Load(object sender, EventArgs e)
    {
        cn.ConnectionString = "Data Source=PRASHANT-PC\\SQLEXPRESS;Initial catalog=Matrimonial1;integrated security=true";

        Label2.Text = Session["G"].ToString();
        Label3.Text = Session["Q"].ToString();
        Label4.Text = Session["R"].ToString();
        Label5.Text = Session["M"].ToString();
        Label6.Text = Session["AF"].ToString();
        Label7.Text = Session["AT"].ToString();
        Label8.Text = Session["C"].ToString();

        if (!IsPostBack)
        {
            string email = "";
            cn.Open();
            cmd.Connection = cn;
            cmd.CommandText = "Select Reg_Email from Register where Reg_No='"+Session["User"].ToString()+"'";
            rs = cmd.ExecuteReader();
            while (rs.Read())
            {
                email = rs.GetValue(0).ToString();
            }
            rs.Close();
            cmd.Dispose();
            cn.Close();

            //Response.Redirect("mailto:"+email+"?Subject=Swayamara&Body=Profile Match");
        }

//        try
//        {

//            send("way2sms_userid", "way2sms_password", txtxmsg.Text,
//txtphn.Text);
//            Response.Write("message send successfully......");
//        }
//        catch
//        {
//            Response.Write("Error Occured!!!");
//        }

        SqlDataSource1.SelectCommand = "select * from User_Profile where Reg_Gender='" + Label2.Text + "' and Reg_Qualification like '%" + Label3.Text + "%' and Reg_Religion like '%" + Label4.Text + "%' and Reg_MotherT like '%" + Label5.Text + "%' and Reg_Age>=" + Label6.Text + " and Reg_Age<=" + Label7.Text + " and Reg_No in (select Reg_No from Register where Reg_Country='" + Label8.Text + "') and Reg_No not in ('" + Session["User"].ToString() +"')";
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["RNO"] = GridView1.SelectedRow.Cells[0].Text;
        Response.Redirect("Select_Profile.aspx");
    }
//    public void send(string uid, string password, string message, string no)
//    {
//        HttpWebRequest myReq =
//(HttpWebRequest)WebRequest.Create("http://ubaid.tk/sms/sms.aspx?uid="
//+ uid + "&pwd=" + password + "&msg=" + message + "&phone=" + no +
//"&provider=way2sms");
//        HttpWebResponse myResp = (HttpWebResponse)myReq.GetResponse();
//        System.IO.StreamReader respStreamReader = new
//System.IO.StreamReader(myResp.GetResponseStream());
//        string responseString = respStreamReader.ReadToEnd();
//        respStreamReader.Close();
//        myResp.Close();
//    }
    
}
